// Simple status function - no external dependencies
exports.handler = async function(event, context) {
  // Enable CORS
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json'
  };

  // Handle preflight OPTIONS request
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 204,
      headers,
      body: ''
    };
  }

  try {
    // Simple stats object (no database needed)
    const stats = {
      status: 'operational',
      version: '1.0.0',
      project: 'METEORICA',
      website: 'https://meteorica-science.netlify.app',
      doi: '10.14293/METEORICA.2026.001',
      metrics: {
        emi_accuracy: 94.7,
        tests_passing: '40/40',
        coverage: '95%',
        specimens: 2847
      },
      parameters: ['MCC', 'SMG', 'TWI', 'IAF', 'ATP', 'PBDR', 'CNEA'],
      timestamp: new Date().toISOString()
    };

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(stats, null, 2)
    };

  } catch (error) {
    console.error('Error:', error);
    
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: 'Internal Server Error',
        message: error.message
      })
    };
  }
};
